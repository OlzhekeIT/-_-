module com.example.mosh_code {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.xerial.sqlitejdbc;

    opens com.example.mosh_code.Market_UI.controller to javafx.fxml;
    opens com.example.mosh_code.Market_UI.app to javafx.fxml;
    exports com.example.mosh_code;
}