package com.example.mosh_code.Market_Model;

public abstract class Product implements HasBasicInfo {

    protected final int id;
    protected String name;
    protected int price; // теңге
    protected String description;
    protected String imagePath;
    protected Product_Category category;

    protected Product(int id, String name, int price,
                      String description, String imagePath,
                      Product_Category category) {

        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name бос болмауы керек");
        if (description == null) description = "";
        if (imagePath == null) imagePath = "";

        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.imagePath = imagePath;
        this.category = category;
    }

    @Override public int getId() { return id; }
    @Override public String getName() { return name; }
    @Override public int getPrice() { return price; }
    @Override public String getDescription() { return description; }
    @Override public String getImagePath() {
        return imagePath;
    }

    public Product_Category getCategory() {
        return category;
    }
}
