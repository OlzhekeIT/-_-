package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.HelloApplication;
import com.example.mosh_code.Market_Model.Product;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Objects;

import static com.example.mosh_code.Market_UI.controller.MainController.showProductDetails;

public class ProductGridController {

    @FXML private FlowPane grid;
    private AppContext ctx;
    private Runnable onCartChanged;
    private MainController mainController;

    public void setContext(AppContext ctx) {
        this.ctx = ctx;
    }

    public void setOnCartChanged(Runnable r) {
        this.onCartChanged = r;
    }

    // ★ ЖАҢА: MainController сүйектеу
    public void setMainController(MainController main) {
        this.mainController = main;
    }

    public void showCategory(String categoryName) {
        grid.getChildren().clear();
        for (Product p : ctx.shopService.getProductsByCategoryName(categoryName)) {
            grid.getChildren().add(card(p));
        }
    }



    public void showSearch(String query) {
        grid.getChildren().clear();
        for (Product p : ctx.shopService.search(query)) {
            grid.getChildren().add(card(p));
        }
    }

    private VBox card(Product p) {
        VBox box = new VBox(8);
        box.setPrefWidth(240);
        box.setStyle("-fx-background-color: white; -fx-padding: 12; -fx-border-color: #E5E7EB; -fx-border-radius: 8;");

        ImageView img = new ImageView();
        img.setFitWidth(210);
        img.setFitHeight(140);
        img.setPreserveRatio(true);
        img.setSmooth(true);

        // ✅ Суретті жүктеу (path дұрыс болса шығады)
        String path = p.getImagePath();
        Image image = loadImageOrPlaceholder(path);
        img.setImage(image);

        Label name = new Label(p.getName());
        name.setStyle("-fx-font-weight: bold;");

        Label price = new Label((int) p.getPrice() + " ₸");
        price.setStyle("-fx-text-fill: #ff6b35; -fx-font-size: 14; -fx-font-weight: bold;");

        Label desc = new Label(p.getDescription());
        desc.setStyle("-fx-font-size: 10; -fx-text-fill: #666;");
        desc.setWrapText(true);

        Button detailsBtn = new Button("Толығырақ →");
        detailsBtn.setPrefWidth(210);
        detailsBtn.setStyle(
                "-fx-padding: 8; " +
                        "-fx-background-color: #17a2b8; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 11; " +
                        "-fx-border-radius: 4;"
        );


        // ✅ алдымен сурет
        box.getChildren().addAll(img, name, price, desc, detailsBtn);
        return box;
    }

    private Image loadImageOrPlaceholder(String path) {
        // placeholder (сенде ондай файл жоқ болса — жасап қой)
        String placeholder = "/com/example/mosh_code/image/Phone/s24ultra.png";

        try {
            if (path == null || path.isBlank()) {
                return new Image(Objects.requireNonNull(getClass().getResource(placeholder)).toExternalForm());
            }
            var url = getClass().getResource(path);
            if (url == null) {
                System.out.println("❌ Image not found: " + path);
                return new Image(Objects.requireNonNull(getClass().getResource(placeholder)).toExternalForm());
            }
            return new Image(url.toExternalForm());
        } catch (Exception e) {
            return new Image(Objects.requireNonNull(getClass().getResource(placeholder)).toExternalForm());
        }
    }
}



