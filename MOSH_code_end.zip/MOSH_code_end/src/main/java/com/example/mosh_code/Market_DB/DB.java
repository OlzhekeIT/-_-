package com.example.mosh_code.Market_DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    private static final String URL ="jdbc:postgresql://localhost:5432/MarketDB";
    private static final String USER = "postgres";
    private static final String PASSWORD = "postgres";




    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL,USER,PASSWORD);
    }
}
