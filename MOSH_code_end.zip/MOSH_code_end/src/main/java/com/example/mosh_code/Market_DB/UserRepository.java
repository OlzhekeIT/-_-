package com.example.mosh_code.Market_DB;

import java.sql.*;

public class UserRepository {

    /** Creates demo user if there is no user in DB; returns its id. */
    public long ensureDemoUser() {
        try (Connection c = DBManager.getConnection()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT id FROM users LIMIT 1")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) return rs.getLong(1);
            }

            try (PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO users(full_name, phone) VALUES(?, ?)",
                    Statement.RETURN_GENERATED_KEYS
            )) {
                ins.setString(1, "Demo Customer");
                ins.setString(2, "+77000000000");
                ins.executeUpdate();
                ResultSet keys = ins.getGeneratedKeys();
                if (keys.next()) return keys.getLong(1);
            }
            throw new SQLException("Failed to create demo user");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
