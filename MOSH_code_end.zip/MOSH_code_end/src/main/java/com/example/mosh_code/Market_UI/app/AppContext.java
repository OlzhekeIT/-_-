package com.example.mosh_code.Market_UI.app;
import com.example.mosh_code.Market_Service.CartService;
import com.example.mosh_code.Market_Service.AccountService;
import com.example.mosh_code.Market_Service.OrderService;
import com.example.mosh_code.Market_Service.ShopService;
import com.example.mosh_code.Market_DB.DBManager;
import com.example.mosh_code.Market_UI.app.UserSession;

public class AppContext {
    public final ShopService shopService = new ShopService();
    // кейін қосамыз:
    // public final CartService cartService = new CartService();
    // public final FavoritesService favoritesService = new FavoritesService();
    public final CartService cartService = new CartService();

    public final AccountService accountService = new AccountService();
    public final OrderService orderService = new OrderService();
    public final UserSession session = new UserSession();

    public AppContext() {
        DBManager.initSchema();
        long userId = accountService.initDemoAccount();
        session.setUserId(userId);
    }
}