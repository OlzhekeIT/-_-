package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_DB.OrderRepository;
import com.example.mosh_code.Market_UI.app.AppContext;
import com.example.mosh_code.Market_UI.controller.UsesContext;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class OrdersController implements UsesContext {

    @FXML
    private TableView<OrderRepository.OrderRow> ordersTable;
    @FXML
    private TableColumn<OrderRepository.OrderRow, Number> idCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, String> customerCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, Number> totalCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, LocalDateTime> dateCol;  // ✅ Object емес, LocalDateTime
    @FXML
    private TableColumn<OrderRepository.OrderRow, String> statusCol;

    private AppContext ctx;

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        setupColumns();
        refresh();
    }

    private void setupColumns() {
        idCol.setCellValueFactory(cd -> cd.getValue().idProperty());
        customerCol.setCellValueFactory(cd -> cd.getValue().customerProperty());
        totalCol.setCellValueFactory(cd -> cd.getValue().totalProperty());
        statusCol.setCellValueFactory(cd -> cd.getValue().statusProperty());

        // ✅ Date колонкасы дұрыс типте
        dateCol.setCellValueFactory(cd -> cd.getValue().dateProperty());

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        dateCol.setCellFactory(col -> new TableCell<OrderRepository.OrderRow, LocalDateTime>() {
            @Override
            protected void updateItem(LocalDateTime item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(fmt.format(item));  // ✅ cast қажет емес
                }
            }
        });
    }

    @FXML
    public void refresh() {
        if (ctx == null) return;
        long userId = ctx.session.getUserId();
        ordersTable.setItems(FXCollections.observableArrayList(ctx.orderService.listOrders(userId)));
    }

    @FXML
    public void cancelSelected() {
        if (ctx == null) return;
        OrderRepository.OrderRow row = ordersTable.getSelectionModel().getSelectedItem();
        if (row == null) return;
        long userId = ctx.session.getUserId();
        ctx.orderService.cancelOrder(userId, row.getId());
        refresh();
    }
}