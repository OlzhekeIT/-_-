package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_UI.app.AppContext;

public interface UsesContext {
    void setContext(AppContext ctx);
}
