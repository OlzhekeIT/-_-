package com.example.mosh_code;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        URL fxml = HelloApplication.class.getResource("/com/example/mosh_code/view/main_shell.fxml");
        if (fxml == null) {
            throw new RuntimeException("FXML not found: /com/example/mosh_code/view/main_shell.fxml");
        }

        FXMLLoader loader = new FXMLLoader(fxml);
        Scene scene = new Scene(loader.load(), 1280, 720);

        // css
        URL css = HelloApplication.class.getResource("/com/example/mosh_code/CSS/style.css");
        if (css != null) scene.getStylesheets().add(css.toExternalForm());

        stage.setTitle("MOSH SHOP");
        stage.setMinWidth(1100);
        stage.setMinHeight(650);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
