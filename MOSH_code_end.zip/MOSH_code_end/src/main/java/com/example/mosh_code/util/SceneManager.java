package com.example.mosh_code.util;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;


public class SceneManager {
    private static Stage mainStage;

    public static void initialize(Stage stage) {
        mainStage = stage;
    }

    public static void switchScene(String fxmlPath) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);

            scene.getStylesheets().add(SceneManager.class.getResource("/com/example/mosh_code/css/style.css").toExternalForm());

            mainStage.setScene(scene);
            mainStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
