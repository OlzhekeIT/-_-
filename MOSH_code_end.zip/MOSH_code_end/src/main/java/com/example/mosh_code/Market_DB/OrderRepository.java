package com.example.mosh_code.Market_DB;

import com.example.mosh_code.Market_Model.CartItem;
import com.example.mosh_code.Market_Model.Order;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class OrderRepository {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public long createPaidOrder(Connection tx, long userId, List<CartItem> items, long total) throws SQLException {
        long orderId;

        try (PreparedStatement ins = tx.prepareStatement(
                "INSERT INTO orders(user_id, created_at, status, total) VALUES(?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
        )) {
            ins.setLong(1, userId);
            ins.setString(2, LocalDateTime.now().format(ISO));
            ins.setString(3, "PAID");
            ins.setLong(4, total);
            ins.executeUpdate();
            ResultSet keys = ins.getGeneratedKeys();
            if (!keys.next()) throw new SQLException("No order id");
            orderId = keys.getLong(1);
        }

        try (PreparedStatement insItem = tx.prepareStatement(
                "INSERT INTO order_items(order_id, product_id, product_name, unit_price, qty, line_total) VALUES(?, ?, ?, ?, ?, ?)"
        )) {
            for (CartItem ci : items) {
                long unit = (long) ci.getProduct().getPrice();
                long line = (long) ci.getTotalPrice();
                insItem.setLong(1, orderId);
                insItem.setInt(2, ci.getProduct().getId());
                insItem.setString(3, ci.getProduct().getName());
                insItem.setLong(4, unit);
                insItem.setInt(5, ci.getQuantity());
                insItem.setLong(6, line);
                insItem.addBatch();
            }
            insItem.executeBatch();
        }

        return orderId;
    }

    /** For Orders page (TableView). */
    public List<OrderRow> listOrders(long userId) {
        List<OrderRow> out = new ArrayList<>();
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT o.id, u.full_name, o.total, o.created_at, o.status " +
                             "FROM orders o JOIN users u ON u.id = o.user_id " +
                             "WHERE o.user_id = ? ORDER BY o.id DESC"
             )) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                long id = rs.getLong(1);
                String customer = rs.getString(2);
                long total = rs.getLong(3);
                String created = rs.getString(4);
                String status = rs.getString(5);
                LocalDateTime dt = LocalDateTime.parse(created, ISO);
                out.add(new OrderRow(id, customer, total, dt, status));
            }
            return out;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public OrderRow findOrder(long orderId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT o.id, u.full_name, o.total, o.created_at, o.status " +
                             "FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ?"
             )) {
            ps.setLong(1, orderId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) return null;
            long id = rs.getLong(1);
            String customer = rs.getString(2);
            long total = rs.getLong(3);
            LocalDateTime dt = LocalDateTime.parse(rs.getString(4), ISO);
            String status = rs.getString(5);
            return new OrderRow(id, customer, total, dt, status);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void setOrderStatus(Connection tx, long orderId, String status) throws SQLException {
        try (PreparedStatement ps = tx.prepareStatement("UPDATE orders SET status = ? WHERE id = ?")) {
            ps.setString(1, status);
            ps.setLong(2, orderId);
            ps.executeUpdate();
        }
    }

    public static class OrderRow extends Order {
        private final javafx.beans.property.StringProperty status = new javafx.beans.property.SimpleStringProperty();

        public OrderRow(long id, String customer, double total, LocalDateTime date, String status) {
            super(id, customer, total, date);
            this.status.set(status);
        }

        public String getStatus() { return status.get(); }
        public void setStatus(String status) { this.status.set(status); }
        public javafx.beans.property.StringProperty statusProperty() { return status; }
    }
}
