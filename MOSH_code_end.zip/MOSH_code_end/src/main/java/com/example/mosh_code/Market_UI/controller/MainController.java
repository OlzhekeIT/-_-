package com.example.mosh_code.Market_UI.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.StackPane;

import com.example.mosh_code.Market_UI.app.AppContext;

public class MainController {

    @FXML
    private StackPane contentHost;

    @FXML private SidebarController sidebarController;
    @FXML private HeaderController headerController;
    @FXML private CartController cartController;

    private final AppContext ctx = new AppContext();
    private ProductGridController currentProductGrid;

    public static void showProductDetails(ScrollPane detailsPage) {
    }

    @FXML
    public void initialize() {
        sidebarController.setMain(this);
        headerController.setContext(ctx);
        cartController.setContext(ctx);

        headerController.setOnSearch(q -> {
            if (currentProductGrid != null) currentProductGrid.showSearch(q);
        });

        showProducts();
    }

    public void showProducts() {
        loadPage("pages/products.fxml");
    }

    public void showOrders() {
        loadPage("pages/orders.fxml");
    }

    public void showCheckout() {
        loadPage("pages/checkout.fxml");
    }

    public void showProfile() {
        loadPage("pages/profile.fxml");
    }

    private void loadPage(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/mosh_code/view/" + fxml));
            Parent page = loader.load();

            Object controller = loader.getController();
            if (controller instanceof UsesContext uc) {
                uc.setContext(ctx);
            }

            // hook product grid to refresh cart and search
            if (controller instanceof ProductsPageController ppc) {
                currentProductGrid = ppc.getProductGridController();
                if (currentProductGrid != null) {
                    currentProductGrid.setOnCartChanged(() -> cartController.refresh());
                    currentProductGrid.showSearch(""); // show all
                }
            } else {
                currentProductGrid = null;
            }

            contentHost.getChildren().setAll(page);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

