package com.example.mosh_code.Market_Model;

public interface SmartphoneSpecs {
    String getBrand();
    String getModel();
    String getProcessor();

    double getDisplayInches();
    double getCameraMegaPixel();
    int getScreenRefreshRate();

    String getOs();
    int getRamGB();
    int getRomGB();

    int getBatteryCapacityMah();
    int getWeightGrams();
}
