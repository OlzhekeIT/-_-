package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_Model.CartItem;
import com.example.mosh_code.Market_Model.Product;

import java.util.ArrayList;
import java.util.List;

public class CartService {

    private final List<CartItem> items = new ArrayList<>();

    public void add(Product product) {
        for (CartItem ci : items) {
            if (ci.getProduct().getId() == product.getId()) {
                ci.addQuantity(1);
                return;
            }
        }
        items.add(new CartItem(product, 1));
    }

    public void removeByProductId(int productId) {
        items.removeIf(ci -> ci.getProduct().getId() == productId);
    }

    public void clear() {
        items.clear();
    }

    public List<CartItem> getItems() {
        return new ArrayList<>(items);
    }

    public double getTotal() {
        double sum = 0;
        for (CartItem ci : items) {
            sum += ci.getTotalPrice();
        }
        return sum;
    }
}

