package com.example.mosh_code.Market_Model;

import javafx.beans.property.*;
import java.time.LocalDateTime;

public class Order {

    private final LongProperty id = new SimpleLongProperty();
    private final StringProperty customer = new SimpleStringProperty();
    private final DoubleProperty total = new SimpleDoubleProperty();
    private final ObjectProperty<LocalDateTime> date = new SimpleObjectProperty<>();

    public Order() {}

    public Order(long id, String customer, double total, LocalDateTime date) {
        this.id.set(id);
        this.customer.set(customer);
        this.total.set(total);
        this.date.set(date);
    }

    // getters
    public long getId() { return id.get(); }
    public String getCustomer() { return customer.get(); }
    public double getTotal() { return total.get(); }
    public LocalDateTime getDate() { return date.get(); }

    // setters
    public void setId(long id) { this.id.set(id); }
    public void setCustomer(String customer) { this.customer.set(customer); }
    public void setTotal(double total) { this.total.set(total); }
    public void setDate(LocalDateTime date) { this.date.set(date); }

    // properties (TableView үшін)
    public LongProperty idProperty() { return id; }
    public StringProperty customerProperty() { return customer; }
    public DoubleProperty totalProperty() { return total; }
    public ObjectProperty<LocalDateTime> dateProperty() { return date; }
}
