package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_Model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ShopService {

    private final List<Product> products = new ArrayList<>();

    public ShopService() {
        seed();
    }

    private void seed() {


        products.add(new Smartphone(
                1,
                "Samsung S24 Ultra",
                499_990,
                "Next-gen Snapdragon, premium build.",
                "/com/example/mosh_code/image/Phone/s24ultra.png",
                "Samsung",
                "S24 Ultra",
                "Qualcomm Snapdragon 8Gen3",
                6.8,
                200,
                120,
                "Android 14",
                16,
                512,
                5000,
                232
        ));


        products.add(new Smartphone(
                2, "Samsung S25 Ultra", 729_990,
                "Next-gen Snapdragon, premium build.",
                "/com/example/mosh_code/image/Phone/s24ultra.png",
                "Samsung", "S25 Ultra", "Qualcomm Snapdragon 8 Elite",
                6.9, 200, 120, "Android 16", 16, 1024, 5000, 218
        ));

        products.add(new Smartphone(
                3, "Samsung S25", 380_000,
                "Next-gen Snapdragon, premium build.",
                "",
                "Samsung", "S25", "Qualcomm Snapdragon 8 Elite",
                6.3, 48, 120, "Android 16", 16, 512, 4000, 168
        ));

        products.add(new Smartphone(
                4, "OnePlus 13", 529_900,
                "Fast performance, smooth display.",
                "",
                "OnePlus", "13", "Qualcomm Snapdragon 8 Elite",
                6.82, 50, 120, "Android 15", 16, 512, 6000, 210
        ));

        products.add(new Smartphone(
                5, "OnePlus 15", 649_990,
                "Fast performance, smooth display.",
                "",
                "OnePlus", "15", "Qualcomm Snapdragon 8 Elite Gen5",
                6.78, 50, 120, "Android 16", 16, 512, 7300, 211
        ));

        products.add(new Smartphone(
                6, "Vivo x200 ultra", 679_990,
                " good cameraphone",
                "",
                "Vivo", "x200 ultra", "Qualcomm Snapdragon 8elite",
                6.82, 200, 120, "Android 15", 16, 512, 6000, 229
        ));

        products.add(new Smartphone(
                7, "Vivo x300 pro", 769_990,
                "",
                "",
                "Vivo", "x300 pro", "MediaTek Dimensity 9500",
                6.78, 200, 120, "Android 16", 16, 512, 6510, 226
        ));

        products.add(new Smartphone(
                8, "Vivo iqoo 12", 459_990,
                "",
                "",
                "Vivo", "iqoo 12", "Qualcomm Snapdragon 8gen3",
                6.8, 64, 144, "Android 14", 16, 512, 5000, 198
        ));

        products.add(new Smartphone(
                9, "Vivo iqoo 15", 759_990,
                "",
                "",
                "Vivo", "iqoo 15", "Qualcomm Snapdragon 8elite Gen5",
                6.85, 50, 120, "Android 16", 16, 512, 7000, 216
        ));

        products.add(new Smartphone(
                10, "Xiaomi 15 Ultra", 679_990,
                "Top camera, flagship chipset.",
                "",
                "Xiaomi", "15 Ultra", "Qualcomm Snapdragon 8 Elite",
                6.73, 50, 120, "Android 15", 16, 1024, 5410, 226
        ));

        products.add(new Smartphone(
                11, "Xiaomi 17 pro max", 889_990,
                "",
                "",
                "Xiaomi", "17 Pro Max", "Qualcomm Snapdragon 8 Elite Gen5",
                6.9, 50, 120, "Android 16", 16, 1024, 7500, 219
        ));

        products.add(new Smartphone(
                12, "Xiaomi 17 pro", 819_990,
                "",
                "",
                "Xiaomi", "17 Pro", "Qualcomm Snapdragon 8 Elite Gen5",
                6.3, 50, 120, "Android 16", 16, 1024, 6300, 192
        ));

        products.add(new Smartphone(
                13, "Xiaomi 17", 610_000,
                "",
                "",
                "Xiaomi", "17", "Qualcomm Snapdragon 8 Elite Gen5",
                6.3, 50, 120, "Android 16", 16, 256, 7000, 191
        ));

        products.add(new Smartphone(
                14, "Google Pixel 10 Pro XL", 685_990,
                "Tensor chip, clean Android experience.",
                "",
                "Google Pixel", "10 Pro XL", "Google Tensor G5",
                6.8, 50, 120, "Android 15", 16, 256, 5200, 232
        ));

        products.add(new Smartphone(
                15, "Google Pixel 10 Pro", 598_000,
                "Tensor chip, clean Android experience.",
                "",
                "Google Pixel", "10 Pro", "Google Tensor G5",
                6.3, 50, 120, "Android 15", 16, 512, 5000, 198
        ));

        products.add(new Smartphone(
                16, "Google Pixel 10", 438_998,
                "Tensor chip, clean Android experience.",
                "",
                "Google Pixel", "10 Pro", "Google Tensor G5",
                6.3, 48, 120, "Android 14", 12, 128, 4970, 204
        ));

        products.add(new Smartphone(
                17, "Google Pixel 9 Pro XL", 898_990,
                "Tensor chip, clean Android experience.",
                "",
                "Google Pixel", "9 Pro XL", "Google Tensor G5",
                6.9, 50, 120, "Android 15", 16, 512, 5200, 230
        ));

        products.add(new Smartphone(
                18, "Iphone 17 pro max", 1600_000,
                "",
                "",
                "Apple", "17 Pro Max", "A 19",
                6.9, 48, 120, "ios 26", 12, 2048, 4823, 233
        ));

        products.add(new Smartphone(
                19, "Iphone 17 pro", 582_000,
                "",
                "",
                "Apple", "17 Pro", "A 19",
                6.3, 48, 120, "ios 26", 12, 512, 3998, 206
        ));

        products.add(new Smartphone(
                120, "Iphone 17", 858_000,
                "",
                "/com/example/mosh_code/image/Phone/iphone17.png",
                "Apple", "17 Pro", "A 19",
                6.3, 48, 60, "ios 26", 8, 256, 3692, 1777
        ));



        // ----- Laptops (сенің қазіргі конструкторыңа сай) -----

//        products.add(new Laptop(
//                10, "MacBook Air M2",
//                "/com.example.mosh_code/images/laptops/macbook_air_m2.png",
//                550_000,
//                "Light, fast, great battery life.",
//                "Apple M2", 8, 256, 13.6, "macOS", "Air M2"
//        ));
//
//        products.add(new Laptop(
//                11, "ASUS TUF Gaming",
//                "/com.example.mosh_code/images/laptops/asus_tuf.png",
//                480_000,
//                "Gaming laptop with strong GPU.",
//                "Intel i7", 16, 512, 15.6, "Windows 11", "TUF"
//        ));
//
//        products.add(new Laptop(
//                12, "Lenovo Legion 5",
//                "/com.example.mosh_code/images/laptops/lenovo_legion.png",
//                649_990,
//                "High refresh, strong cooling, gaming-ready.",
//                "Ryzen 7", 16, 512, 15.6, "Windows 11", "Legion 5"
//        ));
//
//        products.add(new Laptop(
//                13, "HP Pavilion 15",
//                "/com.example.mosh_code/images/laptops/hp_pavilion.png",
//                399_990,
//                "Everyday laptop for study and work.",
//                "Intel i5", 16, 512, 15.6, "Windows 11", "Pavilion 15"
//        ));
//
//        products.add(new Laptop(
//                14, "MacBook Pro M3",
//                "/com.example.mosh_code/images/laptops/macbook_pro_m3.png",
//                899_990,
//                "Pro performance for creators.",
//                "Apple M3", 16, 512, 14.0, "macOS", "Pro M3"
//        ));
    }


    public List<Product> getAllProducts() {
        return List.copyOf(products);
    }

    public List<Product> search(String q) {
        String s = q == null ? "" : q.trim().toLowerCase();
        if (s.isEmpty()) return getAllProducts();
        return products.stream()
                .filter(p -> p.getName().toLowerCase().contains(s))
                .collect(Collectors.toList());
    }

    public List<Product> getByCategory(String categoryName) {
        return products.stream()
                .filter(p -> p.getCategory().equals(categoryName))
                .collect(Collectors.toList());
    }

    // UI controller uses this name
    public List<Product> getProductsByCategoryName(String categoryName) {
        return getByCategory(categoryName);
    }

    public Product findById(int id) {
        return products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }
}