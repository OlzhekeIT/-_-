package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class CheckoutController implements UsesContext {

    @FXML private Label totalLabel;
    @FXML private Label balanceLabel;
    @FXML private Label statusLabel;

    private AppContext ctx;

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        refresh();
    }

    @FXML
    public void refresh() {
        if (ctx == null) return;
        long userId = ctx.session.getUserId();
        long total = (long) ctx.cartService.getTotal();
        long balance = ctx.accountService.getBalance(userId);
        totalLabel.setText("Total: " + total + " ₸");
        balanceLabel.setText("Balance: " + balance + " ₸");
        statusLabel.setText("");
    }

    @FXML
    public void pay() {
        if (ctx == null) return;

        try {
            long userId = ctx.session.getUserId();
            long orderId = ctx.orderService.purchaseCart(userId, ctx.cartService.getItems());
            ctx.cartService.clear();
            long bal = ctx.accountService.getBalance(userId);
            statusLabel.setText("✅ Paid! Order #" + orderId + ". New balance: " + bal + " ₸");
            totalLabel.setText("Total: 0 ₸");
            balanceLabel.setText("Balance: " + bal + " ₸");
        } catch (IllegalStateException ex) {
            statusLabel.setText("❌ " + ex.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace();
            statusLabel.setText("❌ Payment failed. Check console.");
        }
    }
}
