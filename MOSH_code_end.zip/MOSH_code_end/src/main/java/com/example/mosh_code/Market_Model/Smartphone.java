package com.example.mosh_code.Market_Model;

public class Smartphone extends Product implements SmartphoneSpecs {

    private final String brand;
    private final String model;
    private final String processor;
    private final double displayInches;
    private final double cameraMegaPixel;
    private final int screenRefreshRate;
    private final String os;
    private final int ramGB;
    private final int romGB;
    private final int batteryCapacityMah;
    private final int weightGrams;


    public Smartphone(int id,
                      String name,
                      int price,
                      String description,
                      String imagePath,
                      String brand,
                      String model,
                      String processor,
                      double displayInches,
                      double cameraMegaPixel,
                      int screenRefreshRate,
                      String os,
                      int ramGB,
                      int romGB,
                      int batteryCapacityMah,
                      int weightGrams) {

        this(id, name, price, description, imagePath,
                Product_Category.Smartphone,
                brand, model, processor, displayInches, cameraMegaPixel,
                screenRefreshRate, os, ramGB, romGB, batteryCapacityMah, weightGrams);
    }


    public Smartphone(int id,
                      String name,
                      int price,
                      String description,
                      String imagePath,
                      Product_Category category,
                      String brand,
                      String model,
                      String processor,
                      double displayInches,
                      double cameraMegaPixel,
                      int screenRefreshRate,
                      String os,
                      int ramGB,
                      int romGB,
                      int batteryCapacityMah,
                      int weightGrams) {

        super(id, name, price, description, imagePath, category);

        if (brand == null || brand.isBlank()) throw new IllegalArgumentException("brand бос болмауы керек");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("model бос болмауы керек");
        if (processor == null || processor.isBlank()) throw new IllegalArgumentException("processor бос болмауы керек");
        if (os == null || os.isBlank()) throw new IllegalArgumentException("os бос болмауы керек");

        if (displayInches <= 0) throw new IllegalArgumentException("displayInches > 0 болуы керек");
        if (cameraMegaPixel <= 0) throw new IllegalArgumentException("cameraMegaPixel > 0 болуы керек");
        if (screenRefreshRate <= 0) throw new IllegalArgumentException("screenRefreshRate > 0 болуы керек");

        if (ramGB <= 0) throw new IllegalArgumentException("ramGB > 0 болуы керек");
        if (romGB <= 0) throw new IllegalArgumentException("romGB > 0 болуы керек");
        if (batteryCapacityMah <= 0) throw new IllegalArgumentException("batteryCapacityMah > 0 болуы керек");
        if (weightGrams <= 0) throw new IllegalArgumentException("weightGrams > 0 болуы керек");

        this.brand = brand;
        this.model = model;
        this.processor = processor;
        this.displayInches = displayInches;
        this.cameraMegaPixel = cameraMegaPixel;
        this.screenRefreshRate = screenRefreshRate;
        this.os = os;
        this.ramGB = ramGB;
        this.romGB = romGB;
        this.batteryCapacityMah = batteryCapacityMah;
        this.weightGrams = weightGrams;
    }

    @Override public String getBrand() { return brand; }
    @Override public String getModel() { return model; }
    @Override public String getProcessor() { return processor; }
    @Override public double getDisplayInches() { return displayInches; }
    @Override public double getCameraMegaPixel() { return cameraMegaPixel; }
    @Override public int getScreenRefreshRate() { return screenRefreshRate; }
    @Override public String getOs() { return os; }
    @Override public int getRamGB() { return ramGB; }
    @Override public int getRomGB() { return romGB; }
    @Override public int getBatteryCapacityMah() { return batteryCapacityMah; }
    @Override public int getWeightGrams() { return weightGrams; }
}