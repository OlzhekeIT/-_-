package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_DB.CardRepository;
import com.example.mosh_code.Market_DB.DBManager;
import com.example.mosh_code.Market_DB.OrderRepository;
import com.example.mosh_code.Market_Model.CartItem;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/** Handles payment from card balance and order history. */
public class OrderService {

    private final CardRepository cardRepo = new CardRepository();
    private final OrderRepository orderRepo = new OrderRepository();

    /**
     * Returns created order id. Throws IllegalStateException if balance is not enough.
     */
    public long purchaseCart(long userId, List<CartItem> items) {
        long total = items.stream().mapToLong(i -> (long) i.getTotalPrice()).sum();
        if (total <= 0) throw new IllegalStateException("Cart is empty");

        try (Connection tx = DBManager.getConnection()) {
            tx.setAutoCommit(false);
            try {
                long balance = cardRepo.getBalanceByUser(userId);
                if (balance < total) throw new IllegalStateException("Balance is not enough");

                long newBalance = balance - total;
                cardRepo.updateBalanceByUser(tx, userId, newBalance);
                long orderId = orderRepo.createPaidOrder(tx, userId, items, total);

                tx.commit();
                return orderId;
            } catch (RuntimeException | SQLException e) {
                tx.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public java.util.List<OrderRepository.OrderRow> listOrders(long userId) {
        return orderRepo.listOrders(userId);
    }

    /** Refunds money back if order was PAID. */
    public void cancelOrder(long userId, long orderId) {
        OrderRepository.OrderRow row = orderRepo.findOrder(orderId);
        if (row == null) throw new IllegalArgumentException("Order not found");
        if (!"PAID".equalsIgnoreCase(row.getStatus())) return; // already canceled

        long refund = (long) row.getTotal();

        try (Connection tx = DBManager.getConnection()) {
            tx.setAutoCommit(false);
            try {
                long balance = cardRepo.getBalanceByUser(userId);
                cardRepo.updateBalanceByUser(tx, userId, balance + refund);
                orderRepo.setOrderStatus(tx, orderId, "CANCELED");
                tx.commit();
            } catch (RuntimeException | SQLException e) {
                tx.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
