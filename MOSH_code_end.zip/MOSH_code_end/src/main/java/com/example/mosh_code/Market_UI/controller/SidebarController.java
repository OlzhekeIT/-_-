package com.example.mosh_code.Market_UI.controller;

public class SidebarController {

    private MainController main;

    public void setMain(MainController main) {
        this.main = main;
    }

    public void showProducts() {
        main.showProducts();
    }

    public void showOrders() {
        main.showOrders();
    }

    public void showCheckout() {
        main.showCheckout();
    }

    public void showProfile() {
        main.showProfile();
    }
}

