package com.example.mosh_code.Market_DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * SQLite DB manager. Creates mosh.db in the project working directory.
 */
public final class DBManager {

    private static final String URL = "jdbc:sqlite:./mosh.db";

    private DBManager() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    /** Creates tables if they don't exist. Safe to call on every app start. */
    public static void initSchema() {
        try (Connection c = getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("PRAGMA foreign_keys = ON");

            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  full_name TEXT NOT NULL,
                  phone TEXT
                )
            """);

            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS cards (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  card_number TEXT NOT NULL UNIQUE,
                  balance INTEGER NOT NULL,
                  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            """);

            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS orders (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  created_at TEXT NOT NULL,
                  status TEXT NOT NULL,
                  total INTEGER NOT NULL,
                  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            """);

            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS order_items (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  order_id INTEGER NOT NULL,
                  product_id INTEGER NOT NULL,
                  product_name TEXT NOT NULL,
                  unit_price INTEGER NOT NULL,
                  qty INTEGER NOT NULL,
                  line_total INTEGER NOT NULL,
                  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
                )
            """);

        } catch (SQLException e) {
            throw new RuntimeException("DB init failed", e);
        }
    }
}
